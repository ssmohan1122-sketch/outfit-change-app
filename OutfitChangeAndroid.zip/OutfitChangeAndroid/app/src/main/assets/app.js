const statusEl = document.getElementById("status");
const preview = document.getElementById("preview");

document.getElementById("submit").addEventListener("click", async () => {
  const person = document.getElementById("person").files[0];
  const outfit = document.getElementById("outfit").files[0];
  const category = document.getElementById("category").value;
  const description = document.getElementById("description").value || "clothing";

  if (!person || !outfit) {
    statusEl.textContent = "Please select both images.";
    return;
  }

  const form = new FormData();
  form.append("person", person);
  form.append("outfit", outfit);
  form.append("category", category);
  form.append("garment_des", description);

  statusEl.textContent = "Generating outfit... This may take a little while.";
  preview.style.display = "none";

  try {
    const response = await fetch("https://YOUR-BACKEND-DOMAIN.example.com/api/outfit-change", { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Request failed");

    statusEl.textContent = "Outfit generated successfully.";
    preview.src = data.resultUrl;
    preview.style.display = "block";
  } catch (err) {
    statusEl.textContent = err.message;
  }
});
