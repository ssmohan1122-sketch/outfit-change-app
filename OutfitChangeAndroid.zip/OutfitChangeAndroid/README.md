# Outfit Change Android App

Android Studio project using a native WebView shell around the HTML/CSS/JS Outfit Change UI.

## Build a real APK
Open this folder in Android Studio, allow Gradle to sync, then choose **Build > Build APK(s)**.

The generated APK will be under `app/build/outputs/apk/`.

## Backend
The HTML currently points to `https://YOUR-BACKEND-DOMAIN.example.com/api/outfit-change`. Replace that domain with your deployed Node.js backend URL before building.

Keep API keys on the Node.js server, never inside the APK.
